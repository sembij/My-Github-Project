﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AcoraChallenge.Models
{
    public class MockDepartmentRepository: IDepartmentRepository
    {
        public IEnumerable<Department> AllDepartments =>
                new List<Department>
                {
                    new Department{DepartmentId=1,DepartmentName="Orchestration" },
                    new Department{DepartmentId=2,DepartmentName="HR" },
                    new Department{DepartmentId=3,DepartmentName="Sales" }
                };
    }
}
