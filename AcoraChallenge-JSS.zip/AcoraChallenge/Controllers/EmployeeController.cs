﻿using AcoraChallenge.Models;
using AcoraChallenge.ViewModels;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AcoraChallenge.Controllers
{
    public class EmployeeController : Controller
    {
        private readonly IEmployeeRepository _employeeRepository;
        private readonly IDepartmentRepository _departmentRepository;

        public EmployeeController(IEmployeeRepository employeeRepository, IDepartmentRepository departmentRepository)
        {
            _employeeRepository = employeeRepository;
            _departmentRepository = departmentRepository;
        }

        public ViewResult List()
        {
            EmployeesListViewModel employeesListViewModel = new EmployeesListViewModel();
            employeesListViewModel.Employess = _employeeRepository.AllEmployees;

            employeesListViewModel.CurrentCategory = "Employee Data";
            return View(employeesListViewModel);
        }
    }
}
