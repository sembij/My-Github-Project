﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AcoraChallenge.Models
{
    public class MockEmployeeRepository:IEmployeeRepository
    {
        public IEnumerable<Employee> AllEmployees =>
            new List<Employee>
            {
                new Employee{EmployeeNumber=1,DateOfBirth=new DateTime(1988,12,08),DepartmentId=1,FirtName="Jacob",LastName="Wayne" ,Address="1,Long Road,Moseley",City="Birmingham"},
                new Employee{EmployeeNumber=2,DateOfBirth=new DateTime(1970,12,31),DepartmentId=2,FirtName="Lily",LastName="Kent" ,Address="2,The Avenue,King Standing",City="Shorditch"},
                new Employee{EmployeeNumber=3,DateOfBirth=new DateTime(1986,10,04),DepartmentId=3,FirtName="Bipin",LastName="Surti" ,Address="88,Strange Street,Hillfields",City="Coventry"},
                new Employee{EmployeeNumber=4,DateOfBirth=new DateTime(1977,02,12),DepartmentId=1,FirtName="Liam",LastName="Mayne" ,Address="7,Hill Street",City="Solihull"}
            };


        public Employee GetEmpByNumber(int EmployeeNumber)
            {
                return AllEmployees.FirstOrDefault(e => e.EmployeeNumber == EmployeeNumber);
            }
    }
}
